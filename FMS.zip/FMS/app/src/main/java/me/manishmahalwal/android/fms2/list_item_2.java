package me.manishmahalwal.android.fms2;

public class list_item_2 {
    public String id;
    public String worker;
    public String Type;
    public String Status;

    public list_item_2(String id, String worker, String type, String status) {
        this.id = id;
        this.worker = worker;
        Type = type;
        Status = status;
    }
}
