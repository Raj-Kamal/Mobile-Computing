package me.manishmahalwal.android.fms2;

public class Complaint {
    public String complaintNum, complaintType, complaintFrom, complaintTo;
    public int priority;
    public String complaintRoom;
}
