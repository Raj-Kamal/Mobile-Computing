package me.manishmahalwal.android.fms2;

public class list_item {
    public String id;
    public String worker;
    public String Type;
    public String Position;

    public list_item(String id, String worker, String type, String position) {
        this.id = id;
        this.worker = worker;
        Type = type;
        Position = position;
    }
}
